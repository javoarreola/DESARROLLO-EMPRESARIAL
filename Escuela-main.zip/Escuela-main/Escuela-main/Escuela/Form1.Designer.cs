﻿namespace Escuela
{
    partial class panelPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nombre_Completo = new System.Windows.Forms.Label();
            this.consultarBitacora = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Nombre_Completo
            // 
            this.Nombre_Completo.AutoSize = true;
            this.Nombre_Completo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Nombre_Completo.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nombre_Completo.Location = new System.Drawing.Point(128, 21);
            this.Nombre_Completo.Name = "Nombre_Completo";
            this.Nombre_Completo.Size = new System.Drawing.Size(302, 46);
            this.Nombre_Completo.TabIndex = 1;
            this.Nombre_Completo.Text = "Panel Principal";
            // 
            // consultarBitacora
            // 
            this.consultarBitacora.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.consultarBitacora.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.consultarBitacora.ForeColor = System.Drawing.Color.Black;
            this.consultarBitacora.Location = new System.Drawing.Point(13, 108);
            this.consultarBitacora.Name = "consultarBitacora";
            this.consultarBitacora.Size = new System.Drawing.Size(242, 332);
            this.consultarBitacora.TabIndex = 16;
            this.consultarBitacora.Text = "Consultar Bitacora";
            this.consultarBitacora.UseVisualStyleBackColor = false;
            this.consultarBitacora.Click += new System.EventHandler(this.consultarBitacora_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(280, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(242, 332);
            this.button1.TabIndex = 17;
            this.button1.Text = "Registro de Visitante";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.registroVisitante_Click);
            // 
            // panelPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 502);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.consultarBitacora);
            this.Controls.Add(this.Nombre_Completo);
            this.Name = "panelPrincipal";
            this.Text = "Panel Principal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Nombre_Completo;
        private System.Windows.Forms.Button consultarBitacora;
        private System.Windows.Forms.Button button1;
    }
}

