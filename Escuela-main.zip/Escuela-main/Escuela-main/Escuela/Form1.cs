﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Escuela.Vista;

namespace Escuela
{
    public partial class panelPrincipal : Form
    {
        public panelPrincipal()
        {
            InitializeComponent();
        }

        private void consultarBitacora_Click(object sender, EventArgs e)
        {
            Pantalla_B ventanaBitacora = new Pantalla_B();
            ventanaBitacora.Show();
        }

        private void registroVisitante_Click(object sender, EventArgs e)
        {
            Registro_de_visitante ventanaRegistro = new Registro_de_visitante();
            ventanaRegistro.Show();
        }
    }
}
