﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace Escuela
{
    public class Conexion
    {
        private string cadena = ConfigurationManager.ConnectionStrings["ConexionBD"].ConnectionString;

        public SqlConnection ObtenerConexion()
        {
            SqlConnection conexion = new SqlConnection(cadena);
            return conexion;
        }
    }
}


