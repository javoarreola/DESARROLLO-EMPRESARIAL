﻿namespace Escuela.Vista
{
    partial class Registro_de_visitante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nombre_Completo = new System.Windows.Forms.Label();
            this.Empresa = new System.Windows.Forms.Label();
            this.Identificaion = new System.Windows.Forms.Label();
            this.comboTipoDeVisita = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textNombre_completo = new System.Windows.Forms.TextBox();
            this.textBoxEmpresa = new System.Windows.Forms.TextBox();
            this.textBoxIdentificacion = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxMotivo = new System.Windows.Forms.TextBox();
            this.dateTimePickerFecha = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.labelAreaVisita = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Nombre_Completo
            // 
            this.Nombre_Completo.AutoSize = true;
            this.Nombre_Completo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nombre_Completo.Location = new System.Drawing.Point(82, 92);
            this.Nombre_Completo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Nombre_Completo.Name = "Nombre_Completo";
            this.Nombre_Completo.Size = new System.Drawing.Size(287, 37);
            this.Nombre_Completo.TabIndex = 0;
            this.Nombre_Completo.Text = "Nombre Completo:";
            // 
            // Empresa
            // 
            this.Empresa.AutoSize = true;
            this.Empresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Empresa.Location = new System.Drawing.Point(82, 251);
            this.Empresa.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Empresa.Name = "Empresa";
            this.Empresa.Size = new System.Drawing.Size(154, 37);
            this.Empresa.TabIndex = 1;
            this.Empresa.Text = "Empresa:";
            // 
            // Identificaion
            // 
            this.Identificaion.AutoSize = true;
            this.Identificaion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Identificaion.Location = new System.Drawing.Point(82, 411);
            this.Identificaion.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Identificaion.Name = "Identificaion";
            this.Identificaion.Size = new System.Drawing.Size(309, 37);
            this.Identificaion.TabIndex = 2;
            this.Identificaion.Text = "Identificación / Folio:";
            // 
            // comboTipoDeVisita
            // 
            this.comboTipoDeVisita.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboTipoDeVisita.FormattingEnabled = true;
            this.comboTipoDeVisita.Items.AddRange(new object[] {
            "Proveedor",
            "Contratista ",
            "Entrevista",
            "Corporativo",
            "Otro"});
            this.comboTipoDeVisita.Location = new System.Drawing.Point(96, 689);
            this.comboTipoDeVisita.Margin = new System.Windows.Forms.Padding(6);
            this.comboTipoDeVisita.Name = "comboTipoDeVisita";
            this.comboTipoDeVisita.Size = new System.Drawing.Size(792, 50);
            this.comboTipoDeVisita.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(82, 594);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tipo de Visita:";
            // 
            // textNombre_completo
            // 
            this.textNombre_completo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNombre_completo.Location = new System.Drawing.Point(96, 169);
            this.textNombre_completo.Margin = new System.Windows.Forms.Padding(6);
            this.textNombre_completo.Name = "textNombre_completo";
            this.textNombre_completo.Size = new System.Drawing.Size(792, 50);
            this.textNombre_completo.TabIndex = 5;
            // 
            // textBoxEmpresa
            // 
            this.textBoxEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmpresa.Location = new System.Drawing.Point(96, 328);
            this.textBoxEmpresa.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxEmpresa.Name = "textBoxEmpresa";
            this.textBoxEmpresa.Size = new System.Drawing.Size(792, 50);
            this.textBoxEmpresa.TabIndex = 6;
            // 
            // textBoxIdentificacion
            // 
            this.textBoxIdentificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIdentificacion.Location = new System.Drawing.Point(96, 488);
            this.textBoxIdentificacion.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxIdentificacion.Name = "textBoxIdentificacion";
            this.textBoxIdentificacion.Size = new System.Drawing.Size(792, 50);
            this.textBoxIdentificacion.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(82, 790);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 37);
            this.label2.TabIndex = 8;
            this.label2.Text = "Motivo:";
            // 
            // textBoxMotivo
            // 
            this.textBoxMotivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotivo.Location = new System.Drawing.Point(96, 866);
            this.textBoxMotivo.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxMotivo.Multiline = true;
            this.textBoxMotivo.Name = "textBoxMotivo";
            this.textBoxMotivo.Size = new System.Drawing.Size(792, 260);
            this.textBoxMotivo.TabIndex = 9;
            // 
            // dateTimePickerFecha
            // 
            this.dateTimePickerFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerFecha.Location = new System.Drawing.Point(96, 1424);
            this.dateTimePickerFecha.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimePickerFecha.Name = "dateTimePickerFecha";
            this.dateTimePickerFecha.Size = new System.Drawing.Size(792, 50);
            this.dateTimePickerFecha.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(82, 1347);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 37);
            this.label3.TabIndex = 11;
            this.label3.Text = "Fecha:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(82, 1521);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 37);
            this.label4.TabIndex = 12;
            this.label4.Text = "Status:";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxStatus.FormattingEnabled = true;
            this.comboBoxStatus.Items.AddRange(new object[] {
            "En sitio ",
            "Salió ",
            "Denegado"});
            this.comboBoxStatus.Location = new System.Drawing.Point(96, 1598);
            this.comboBoxStatus.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(792, 50);
            this.comboBoxStatus.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(96, 1743);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(329, 137);
            this.button1.TabIndex = 14;
            this.button1.Text = "Limpiar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(563, 1743);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(325, 137);
            this.button2.TabIndex = 15;
            this.button2.Text = "Guardar";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // labelAreaVisita
            // 
            this.labelAreaVisita.AutoSize = true;
            this.labelAreaVisita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAreaVisita.Location = new System.Drawing.Point(82, 1163);
            this.labelAreaVisita.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelAreaVisita.Name = "labelAreaVisita";
            this.labelAreaVisita.Size = new System.Drawing.Size(220, 37);
            this.labelAreaVisita.TabIndex = 17;
            this.labelAreaVisita.Text = "Area a Visitar:";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Rh ",
            "Imp/Exp, ",
            "Sistemas",
            "Otro"});
            this.comboBox1.Location = new System.Drawing.Point(96, 1257);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(6);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(792, 50);
            this.comboBox1.TabIndex = 16;
            // 
            // Registro_de_visitante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1020, 1655);
            this.Controls.Add(this.labelAreaVisita);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBoxStatus);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateTimePickerFecha);
            this.Controls.Add(this.textBoxMotivo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxIdentificacion);
            this.Controls.Add(this.textBoxEmpresa);
            this.Controls.Add(this.textNombre_completo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboTipoDeVisita);
            this.Controls.Add(this.Identificaion);
            this.Controls.Add(this.Empresa);
            this.Controls.Add(this.Nombre_Completo);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Registro_de_visitante";
            this.Text = "Registro de Visitante";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Nombre_Completo;
        private System.Windows.Forms.Label Empresa;
        private System.Windows.Forms.Label Identificaion;
        private System.Windows.Forms.ComboBox comboTipoDeVisita;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textNombre_completo;
        private System.Windows.Forms.TextBox textBoxEmpresa;
        private System.Windows.Forms.TextBox textBoxIdentificacion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxMotivo;
        private System.Windows.Forms.DateTimePicker dateTimePickerFecha;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelAreaVisita;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}