﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escuela.Vista
{
    public partial class Registro_de_visitante : Form
    {
        public Registro_de_visitante()
        {
            InitializeComponent();
        }
    }
}
