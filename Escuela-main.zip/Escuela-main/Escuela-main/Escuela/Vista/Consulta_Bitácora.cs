﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Escuela.Vista
{
    public partial class Pantalla_B : Form
    {
        Conexion conexion = new Conexion();

        public Pantalla_B()
        {
            InitializeComponent();
        }

        private void Pantalla_B_Load(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = conexion.ObtenerConexion())
                {
                    con.Open();
                }

                CargarEstatus();
                CargarBitacora();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de conexión: " + ex.Message);
            }
        }

        private void CargarEstatus()
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Todos");
            comboBox1.Items.Add("EnSitio");
            comboBox1.Items.Add("Salio");
            comboBox1.Items.Add("Denegado");
            comboBox1.SelectedIndex = 0;
        }

        private void CargarBitacora()
        {
            try
            {
                using (SqlConnection con = conexion.ObtenerConexion())
                {
                    string query = @"
                        SELECT
                            a.AccesoID,
                            p.TipoPersona,
                            p.NombreCompleto,
                            p.Empresa,
                            a.TipoAcceso,
                            a.MotivoVisita,
                            a.Anfitrion,
                            a.AreaDestino,
                            a.FechaHoraEntrada,
                            a.FechaHoraSalida,
                            a.Estatus,
                            a.CapturadoPor
                        FROM Accesos a
                        INNER JOIN Personas p ON a.PersonaID = p.PersonaID
                        ORDER BY a.FechaHoraEntrada DESC";

                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar bitácora: " + ex.Message);
            }
        }

        private void buttonBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = conexion.ObtenerConexion())
                {
                    string query = @"
                        SELECT
                            a.AccesoID,
                            p.TipoPersona,
                            p.NombreCompleto,
                            p.Empresa,
                            a.TipoAcceso,
                            a.MotivoVisita,
                            a.Anfitrion,
                            a.AreaDestino,
                            a.FechaHoraEntrada,
                            a.FechaHoraSalida,
                            a.Estatus,
                            a.CapturadoPor
                        FROM Accesos a
                        INNER JOIN Personas p ON a.PersonaID = p.PersonaID
                        WHERE CAST(a.FechaHoraEntrada AS DATE) BETWEEN @Desde AND @Hasta
                        AND (
                            p.NombreCompleto LIKE @Busqueda OR
                            p.Empresa LIKE @Busqueda OR
                            a.MotivoVisita LIKE @Busqueda
                        )
                        AND (@Estatus = 'Todos' OR a.Estatus = @Estatus)
                        ORDER BY a.FechaHoraEntrada DESC";

                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    da.SelectCommand.Parameters.AddWithValue("@Desde", dateTimePicker1.Value.Date);
                    da.SelectCommand.Parameters.AddWithValue("@Hasta", dateTimePicker2.Value.Date);
                    da.SelectCommand.Parameters.AddWithValue("@Busqueda", "%" + textBoxEmpresa.Text.Trim() + "%");
                    da.SelectCommand.Parameters.AddWithValue("@Estatus", comboBox1.Text);

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en búsqueda: " + ex.Message);
            }
        }
    }
}